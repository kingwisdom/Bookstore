
//create data class
function Book(title, author, isbn){
  this.title = title;
  this.author = author;
  this.isbn = isbn;
}

//store in LS


//ccreate a UI constructor
function UI(){}
UI.prototype.addbookToList = function(book){
  const tr = document.createElement('tr');
  tr.innerHTML = `
                <td>${book.title}</td>
                <td>${book.author}</td>
                <td>${book.isbn}</td>
                <td><a href='#' class="delete">X</a></td>
                `;
  const tbody = document.querySelector('#book-list');
  tbody.appendChild(tr);
}
UI.prototype.showmessage = function(msg, className) {
  const div = document.createElement('div');
  div.className = `alert ${className}`;
  div.appendChild(document.createTextNode(msg));
  //all div to dom
  const container = document.querySelector('.column');

  const form = document.querySelector('#book-form');
 
  container.insertBefore(div, form);
  
  //set time out 
  setTimeout(function(){
    document.querySelector('.alert').remove()
  }, 2000);
}

UI.prototype.removeBook = function(target){
  if(target.className === 'delete'){
    target.parentElement.parentElement.remove();
  }
}

document.getElementById('book-form').addEventListener('submit',function(e){
  const title = document.getElementById('book-title').value;
  const author = document.getElementById('book-author').value;
  const isbn = document.getElementById('book-isbn').value;

  //instantiate Book constructor
  const book = new Book(title,author,isbn);
  
  const ui = new UI();
  //validate form 
  if(title==='' || author=='' || isbn==''){
    ui.showmessage('Fill all fields', 'error');
  } else{
    
    ui.addbookToList(book); 
    ui.showmessage('Book Added!', 'success');
  }
  
  e.preventDefault();
});
document.getElementById('book-list').addEventListener('click', function(e){
  const ui = new UI();
  ui.removeBook(e.target);

  //show alert
  ui.showmessage('Book Deleted successfully', 'success');
  e.preventDefault()
})