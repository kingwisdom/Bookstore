class Book{
  constructor(title,author,isbn){
    this.title = title;
    this.author = author;
    this.isbn = isbn;
  }
}
//store in LS
class Store{
  static getBooks() {
    let books;
    if(localStorage.getItem('books') === null) {
      books = [];
    } else {
      books = JSON.parse(localStorage.getItem('books'));
    }

    return books;
  }

  static addBook(book) {
    const books = Store.getBooks();

    books.push(book);

    localStorage.setItem('books', JSON.stringify(books));
  }

  static displayBook() {
    const books = Store.getBooks();

    books.forEach(function(book){
      const ui = new UI;
      ui.addbookToList(book);
    });
    localStorage.setItem('books', JSON.stringify(books));

  }
  static deleteBook(isbn) {
    const books = Store.getBooks();

    books.forEach(function(book,index){
     if(book.isbn === isbn){
       books.splice(book, 1);
     }
    });
    localStorage.setItem('books', JSON.stringify(books));
  }
}

class UI{
  addbookToList(book) {
    const tr = document.createElement('tr');
  tr.innerHTML = `
                <td>${book.title}</td>
                <td>${book.author}</td>
                <td>${book.isbn}</td>
                <td><a href='#' class="delete">X</a></td>
                `;
  const tbody = document.querySelector('#book-list');
  tbody.appendChild(tr);

  }

  showmessage(msg, className) {
    const div = document.createElement('div');
    div.className = `alert ${className}`;
    div.appendChild(document.createTextNode(msg));
    //all div to dom
    const container = document.querySelector('.column');
  
    const form = document.querySelector('#book-form');
   
    container.insertBefore(div, form);
    
    //set time out 
    setTimeout(function(){
      document.querySelector('.alert').remove()
    }, 2000);
  }

  removeBook(target){
    if(target.className === 'delete'){
      if(confirm('Are you sure?')) {
        target.parentElement.parentElement.remove();
      }
    }
  }

}

document.addEventListener('DOMContentLoaded', Store.displayBook);

document.getElementById('book-form').addEventListener('submit',function(e){
  const title = document.getElementById('book-title').value;
  const author = document.getElementById('book-author').value;
  const isbn = document.getElementById('book-isbn').value;

  //instantiate Book constructor
  const book = new Book(title,author,isbn);
  
  const ui = new UI();
  //validate form
  if(title==='' || author=='' || isbn==''){
    ui.showmessage('Fill all fields', 'error');
  } else{
    
    ui.addbookToList(book); 
    Store.addBook(book);
    ui.showmessage('Book Added!', 'success');
  }
  
  e.preventDefault();
});


document.getElementById('book-list').addEventListener('click', function(e){
  const ui = new UI();
  ui.removeBook(e.target);

  Store.deleteBook(e.target.parentElement.previousElementSibling.textContent)

  //show alert
  ui.showmessage('Book Deleted successfully', 'success');
  e.preventDefault()
})